export const categories = {
  amor: 'Amor',
};