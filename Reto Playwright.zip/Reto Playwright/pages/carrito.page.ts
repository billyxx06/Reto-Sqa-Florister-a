import { Page, expect } from '@playwright/test';

export class CarritoPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async validateNumberOfItems(expected: number) {
    const items = this.page.locator('.cart_item');
    await expect(items).toHaveCount(expected);
  }

  async getProductNames() {
    return this.page.locator('.cart_item .product-name a').allTextContents();
  }

  async getProductPrices() {
    return this.page.locator('.cart_item .product-price .woocommerce-Price-amount').allTextContents();
  }

  async getSubtotal() {
    const subtotalText = await this.page.locator('.cart-subtotal .woocommerce-Price-amount').textContent();
    return parseFloat(subtotalText!.replace(/[^0-9,]/g, '').replace(',', '.'));
  }
}
