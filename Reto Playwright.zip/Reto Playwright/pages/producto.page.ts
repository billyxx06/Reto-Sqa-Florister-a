import { Page, expect } from '@playwright/test';

export class ProductoPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async getProductName() {
    return this.page.locator('h1.product_title').textContent();
  }

  async getProductPrice() {
    return this.page.locator('.woocommerce-Price-amount').first().textContent();
  }

  async addToCart() {
    const button = this.page.getByRole('button', { name: /añadir al carrito/i });
    await expect(button).toBeVisible({ timeout: 5000 });
    await button.click();
  }
}
