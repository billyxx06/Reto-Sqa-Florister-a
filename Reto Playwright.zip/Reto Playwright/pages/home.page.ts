import { Page, expect } from '@playwright/test';

export class HomePage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async goto() {
    await this.page.goto('https://www.floristeriamundoflor.com/');
  }

  async goToCategory(categoryName: string) {
    const categoryUrl = `https://www.floristeriamundoflor.com/product-category/${categoryName.toLowerCase()}/`;
    console.log(`➡ Navegando directamente a la categoría: ${categoryUrl}`);

    await this.page.goto(categoryUrl, { waitUntil: 'domcontentloaded' });
    await expect(this.page).toHaveURL(categoryUrl, { timeout: 15000 });

    await this.page.waitForSelector('div.product-block.grid', { timeout: 30000 });

    console.log("✅ Productos cargados correctamente");
  }
}

