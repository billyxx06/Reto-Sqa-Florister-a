import { Page, expect } from '@playwright/test';

export class CategoriaPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async selectProductByIndex(index: number) {
    const products = this.page.locator('div.product-block.grid');

    await expect(products.first()).toBeVisible({ timeout: 15000 });

    const count = await products.count();
    console.log(`Se encontraron ${count} productos en la categoría`);

    if (index < 0 || index >= count) {
      throw new Error(`Índice fuera de rango: ${index}. Total productos: ${count}`);
    }

    return products.nth(index);
  }

  async addProductToCartByIndex(index: number) {
    const product = await this.selectProductByIndex(index);

    const productName = (await product.locator('h3.name').innerText()).trim();
    const productPrice = (await product.locator('.price').innerText()).trim();
    console.log(`Seleccionando producto: ${productName} - Precio: ${productPrice}`);

    await product.scrollIntoViewIfNeeded();
    await product.hover();

    const addButton = product.locator('a.add_to_cart_button');

    await addButton.waitFor({ state: 'visible', timeout: 8000 });
    await addButton.scrollIntoViewIfNeeded();

    await this.page.waitForTimeout(120);

    try {
      await addButton.click({ timeout: 2000 });
    } catch (e1) {
      console.warn('⚠ Click normal falló, reintentando centrar y click de nuevo…');

      await product.scrollIntoViewIfNeeded();
      await product.hover();
      await addButton.scrollIntoViewIfNeeded();
      await this.page.waitForTimeout(120);

      try {
        await addButton.click({ timeout: 2000 });
      } catch (e2) {
        console.warn('⚠ Aún falla. Ejecutando click por JS como último recurso');
        
        const handle = await addButton.elementHandle();
        await handle!.evaluate((el) => (el as HTMLElement).click());
      }
    }

    await this.page.waitForSelector('.woocommerce-message, .added_to_cart', {
      timeout: 10000,
    });

    return { name: productName, price: productPrice };
  }
}

