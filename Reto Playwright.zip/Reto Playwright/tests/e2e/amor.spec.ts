// tests/e2e/amor.spec.ts
import { test, expect } from '@playwright/test';
import { HomePage } from '../../pages/home.page';
import { CategoriaPage } from '../../pages/categoria.page';

test.describe('Escenario 1 - Amor', () => {
  test.setTimeout(70000); 

  test('Agregar dos productos de Amor al carrito', async ({ page }) => {
    const homePage = new HomePage(page);
    const categoriaPage = new CategoriaPage(page);

    await homePage.goToCategory('amor');
    await expect(page.locator('div.product-block.grid').first()).toBeVisible({ timeout: 15000 });

    const product1 = await categoriaPage.addProductToCartByIndex(0);
    console.log(`✅ Primer producto agregado: ${product1.name} - ${product1.price}`);

    await page.goto('https://www.floristeriamundoflor.com/product-category/amor/', { waitUntil: 'domcontentloaded' });
    await expect(page.locator('div.product-block.grid').first()).toBeVisible({ timeout: 15000 });

    const product2 = await categoriaPage.addProductToCartByIndex(1);
    console.log(`✅ Segundo producto agregado: ${product2.name} - ${product2.price}`);


    const viewCart = page.locator('a.added_to_cart.wc-forward').last();
    if (await viewCart.isVisible({ timeout: 5000 }).catch(() => false)) {
      await viewCart.click();
    } else {
      await page.goto('https://www.floristeriamundoflor.com/carrito/', { waitUntil: 'domcontentloaded' });
    }

    console.log('URL carrito actual:', page.url());

    const cartReady = async () => {
      const candidates = [
        'body.woocommerce-cart',
        '.woocommerce-cart-form',
        'form.woocommerce-cart-form',
        '.shop_table.cart',
        '.cart_totals',
        '.cart_item'
      ];
      for (const sel of candidates) {
        const loc = page.locator(sel);
        if (await loc.first().isVisible({ timeout: 2000 }).catch(() => false)) return true;
      }
      return false;
    };

    const refreshReq = page
      .waitForResponse(
        (r) => r.url().includes('wc-ajax=get_refreshed_fragments') && r.status() === 200,
        { timeout: 12000 }
      )
      .catch(() => undefined);

    const seenAny = (async () => {
      const start = Date.now();
      while (Date.now() - start < 20000) {
        if (await cartReady()) return true;
        await page.waitForTimeout(400);
      }
      return false;
    })();

    await Promise.race([refreshReq, seenAny]);

    
    const cartItems = page.locator('.woocommerce-cart-form .cart_item, .shop_table.cart tr.cart_item');


    await expect(cartItems.first()).toBeVisible({ timeout: 20000 });

    await expect(cartItems).toHaveCount(2, { timeout: 20000 });

    console.log('🛒 Validación OK: se encontraron 2 productos en el carrito ✅');

  });
});


